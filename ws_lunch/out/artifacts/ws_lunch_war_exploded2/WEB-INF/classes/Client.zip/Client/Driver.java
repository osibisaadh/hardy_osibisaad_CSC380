package Client;

import models.menu.Item;
import models.order.Order;
import models.restarants.Restaurant;
import models.restarants.Restaurants;
import sun.net.www.protocol.http.HttpURLConnection;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;
import java.util.Scanner;

/**
 * Created with IntelliJ IDEA.
 * User: Osibisaad
 * Date: 7/24/13
 * Time: 7:16 PM
 * To change this template use File | Settings | File Templates.
 */
public class Driver {

    private static Unmarshaller unmarshaller;
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args){
        try{

            System.out.println("started");
            URL Index = new URL("http://localhost:8080/restaurants");
            URLConnection indexConnect = Index.openConnection();
            InputStream in =indexConnect.getInputStream();

            JAXBContext jaxbContext = JAXBContext.newInstance("models");
            unmarshaller = jaxbContext.createUnmarshaller();
            Restaurant restaurant = getRestaurant(in);

            URL menu = new URL("http://localhost:8080/Menu/" + restaurant.getName());
            URLConnection menuConnection = menu.openConnection();

            in =menuConnection.getInputStream();

            Item item = getItem(in);

            URL orderURL = new URL("http://localhost:8080/Order");
            HttpURLConnection orderConnection = (HttpURLConnection)orderURL.openConnection();
            orderConnection.setDoOutput(true);
            orderConnection.setRequestMethod("PUT");

            Order order = new Order();
            order.setItem(item);
            order.setRestaurant(restaurant);

            Marshaller marshaller = jaxbContext.createMarshaller();
            File xml = new File("order.xml");
            marshaller.marshal(order, xml);

            PrintWriter out = new PrintWriter(orderConnection.getOutputStream());
            out.print(xml);
            out.close();
            in = orderConnection.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            br.readLine();
            br.close();

        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public static Item getItem(InputStream in) throws JAXBException {
        Item choice = null;
        List<Item> itemList = (List<Item>) unmarshaller.unmarshal(in);
        boolean valid = false;
        while(!valid){
            System.out.println("Choose Item: ");
            for(int i = 0; i < itemList.size();i++){
                System.out.println(i + ": " + itemList.get(i));
            }
            try{
                String index = scanner.nextLine();
                choice = itemList.get(Integer.parseInt(index));
                valid = true;

            }catch(Exception e){
                e.printStackTrace();
            }
        }
        return choice;

    }

    public static Restaurant getRestaurant(InputStream in) throws JAXBException {
        Restaurant choice = null;
        Restaurants restaurants= (Restaurants) unmarshaller.unmarshal(in);
        List<Restaurant> restaurantList =  restaurants.getRestaurants();
        boolean valid = false;
        while(!valid){
            System.out.println("Choose restaurant: ");
            for(int i = 0; i < restaurantList.size();i++){
                System.out.println(i + ": " + restaurantList.get(i));
            }
            try{
                String index = scanner.nextLine();
                choice = restaurantList.get(Integer.parseInt(index));
                valid = true;

            }catch(Exception e){
                e.printStackTrace();
            }
        }
        return choice;

    }

}
