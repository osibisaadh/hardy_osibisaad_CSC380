package sevlets;

import DB.DataHolder;
import models.restarants.Restaurant;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import java.io.File;
import java.io.IOException;
import java.util.List;

/** User: zacharyhunt Date: 7/24/13 */

@WebServlet ("/restaurants")
public class RestuarantsServlet extends HttpServlet
{
    DataHolder dataHolder = DataHolder.getInstance();

    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        List<Restaurant> restaurants = dataHolder.getRestaurantWithoutMenus();
        System.out.println("COnnected");

        JAXBContext jaxbContext;
        try
        {
            jaxbContext = JAXBContext.newInstance("model");
            Marshaller marshaller = jaxbContext.createMarshaller();

            File xml = new File("restaurants.xml");
            marshaller.marshal(restaurants, xml);

            response.addHeader("Content Type", "text/xml");
            response.getWriter().print(xml);
        }
        catch (JAXBException e)
        {
            e.printStackTrace();
        }
    }

    @Override
    public void init() throws ServletException {
        System.out.println("Create");
        super.init();    //To change body of overridden methods use File | Settings | File Templates.
    }
}