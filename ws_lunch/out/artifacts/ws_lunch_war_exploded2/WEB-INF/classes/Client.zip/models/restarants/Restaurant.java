package models.restarants;

import models.menu.Menu;

import javax.xml.bind.annotation.*;

/** User: zacharyhunt Date: 7/22/13 */

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType (name = "restaurant", propOrder = {
        "name",
        "menu"
})
public class Restaurant
{
    @XmlAttribute(name = "name", required = true)
    protected String name;

    @XmlElement(name = "menu", required = false)
    protected Menu menu;

    public void setName(String name)
    {
        this.name = name;
    }

    public void setMenu(Menu menu)
    {
        this.menu = menu;
    }

    public String getName()
    {
        return name;
    }

    public Menu getMenu()
    {
        return menu;
    }
}