package models.restarants;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

/** User: zacharyhunt Date: 7/24/13 */

@XmlRootElement
public class Restaurants
{
    @XmlElement (nillable = false, name = "restaurant", required = true)
    protected List<Restaurant> restaurants;

    public List<Restaurant> getRestaurants()
    {
        return restaurants;
    }

    public Restaurants getRestaurantsObject()
    {
        return this;
    }

    public void addRetuarant(Restaurant restuarant)
    {
        this.restaurants.add(restuarant);
    }
}