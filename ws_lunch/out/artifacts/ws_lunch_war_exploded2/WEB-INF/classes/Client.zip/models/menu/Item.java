package models.menu;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;

/** User: zacharyhunt Date: 7/24/13 */

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType (name = "item", propOrder = {
        "name",
        "price"
})
public class Item
{
    @XmlAttribute(name = "name", required = true)
    protected String name;

    @XmlAttribute(name = "price", required = true)
    protected double price;

    public void setName(String name)
    {
        this.name = name;
    }

    public void setPrice(double price)
    {
        this.price = price;
    }

    public String getName()
    {
        return name;
    }

    public double getPrice()
    {
        return price;
    }
}