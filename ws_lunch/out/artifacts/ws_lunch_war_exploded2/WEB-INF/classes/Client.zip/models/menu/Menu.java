package models.menu;

import models.menu.Item;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.*;
import java.util.List;

/** User: zacharyhunt Date: 7/24/13 */

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType (name = "menu", propOrder = {
        "items"
})
@XmlRootElement
public class Menu
{
    @XmlElement (nillable = false, name = "item", required = true)
    protected List<Item> items;

    public void setItems(List<Item> items)
    {
        this.items = items;
    }

    public List<Item> getItems()
    {
        return items;
    }
}