package models.order;

import models.menu.Item;
import models.restarants.Restaurant;

import javax.xml.bind.annotation.XmlRootElement;

/** User: zacharyhunt Date: 7/25/13 */

@XmlRootElement
public class Order
{
    private Restaurant restaurant;
    private Item item;

    public Restaurant getRestaurant()
    {
        return restaurant;
    }

    public void setRestaurant(Restaurant restaurant)
    {
        this.restaurant = restaurant;
    }

    public Item getItem()
    {
        return item;
    }

    public void setItem(Item item)
    {
        this.item = item;
    }
}
