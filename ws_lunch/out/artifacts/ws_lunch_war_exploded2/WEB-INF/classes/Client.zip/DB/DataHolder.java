package DB;

import models.menu.Item;
import models.menu.Menu;
import models.restarants.Restaurant;
import models.restarants.Restaurants;

import java.util.ArrayList;
import java.util.List;

/** User: zacharyhunt Date: 7/25/13 */
public class DataHolder
{
    private static DataHolder dataHolder = new DataHolder();
    private static Restaurants restuarantManager = new Restaurants();

    public static DataHolder getInstance()
    {
        instantiateRestaurants();
        if (dataHolder == null)
        {
            dataHolder = new DataHolder();
        }
        return dataHolder;
    }

    public Restaurants getRestuarantManager()
    {
        return this.restuarantManager;
    }

    public Restaurant getRestaurant(String name)
    {
        Restaurant restaurant = null;
        for (Restaurant r : this.getRestuarantManager().getRestaurants())
        {
            if (r.getName().equalsIgnoreCase(name))
            {
                restaurant = new Restaurant();
                restaurant.setName(r.getName());
                restaurant.setMenu(r.getMenu());
            }
        }
        return restaurant;
    }

    public List<Restaurant> getRestaurantWithoutMenus()
    {
        List<Restaurant> tempRestaurants = this.getRestuarantManager().getRestaurants();
        for (Restaurant r : tempRestaurants)
        {
            r.setMenu(null);
        }
        return tempRestaurants;
    }

    private static void instantiateRestaurants()
    {
        Menu lukesMenu = new Menu();
        Item i1 = new Item();
        i1.setName("Bacon Hamburger");
        i1.setPrice(11.00);

        Item i2 = new Item();
        i1.setName("Cinnamon French Toast");
        i1.setPrice(6.00);

        Item i3 = new Item();
        i1.setName("Dog");
        i1.setPrice(3.00);

        List<Item> lukesMenuItems = new ArrayList<Item>();
        lukesMenuItems.add(i1);
        lukesMenuItems.add(i2);
        lukesMenuItems.add(i3);

        lukesMenu.setItems(lukesMenuItems);

        Restaurant lukes = new Restaurant();
        lukes.setName("Luke's Diner");
        lukes.setMenu(lukesMenu);

        restuarantManager.addRetuarant(lukes);

        Menu tinasMenu = new Menu();
        Item i4 = new Item();
        i1.setName("Scone");
        i1.setPrice(11.00);

        Item i5 = new Item();
        i1.setName("Dried Fruit");
        i1.setPrice(6.00);

        Item i6 = new Item();
        i1.setName("Possum");
        i1.setPrice(3.00);

        List<Item> tinasMenuItems = new ArrayList<Item>();
        tinasMenuItems.add(i4);
        tinasMenuItems.add(i5);
        tinasMenuItems.add(i6);

        tinasMenu.setItems(tinasMenuItems);

        Restaurant tinas = new Restaurant();
        tinas.setName("Tina' Kitchen");
        tinas.setMenu(tinasMenu);

        restuarantManager.addRetuarant(tinas);
    }

    private DataHolder() {}
}
